package com.zybooks.studyhelpergame;

import android.content.Intent;
import android.graphics.drawable.AnimationDrawable;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TableLayout;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    Button creatBttn;

    AnimationDrawable animationDrawable;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        creatBttn = findViewById(R.id.createBtn);
//        myTableLayout = findViewById(R.id.mainActLayout);
        animationDrawable = (AnimationDrawable) creatBttn.getBackground();
        animationDrawable.setEnterFadeDuration(1000);
        animationDrawable.setExitFadeDuration(4000);
        animationDrawable.start();

    }

    public void playBtn(View view)
    {
        Intent myIntent = new Intent(this, LogInActivity.class);

        this.startActivity(myIntent);
    }
}